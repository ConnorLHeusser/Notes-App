#refactored to force notes as string
def collect_notes():
    notes = input(str("Please enter what notes you would like to enter (type exit to exit): "))
    newNotes = ""
    #decluttered while loop with better logic 
    while (newNotes!= "exit"):
        newNotes = input(str("Please continue entering notes (Type exit to exit): "))
        notes += " " + newNotes
        print(f"Notes so far: {notes}")
    
    print(f"Final notes: {notes}")
    return notes

def collect_notes_testable(inputs):
    #Testable version of code
    input = iter(inputs)
        
    notes = next(inputs)  # First input
    newNotes = ""
    
    while newNotes != "exit":
        newNotes = next(inputs)  # Subsequent inputs
        notes += " " + newNotes
        print(f"Notes so far: {notes}")
    
    print(f"Final notes: {notes}")
    return notes

#added final printout of notes taken 
